package CollectionDemo;

public class ArrayDemo {
	public static void main(String[] args) {
		
		String s1 = "vaule1";
		
		int i1 = 10;
		
		
		int [] arr1 = {10,20,30,40,50};
		
		int len = arr1.length;
		
		for(int i =0; i<len;i++)
		{
		System.out.println(arr1[i]);
		
		}
		
	}

}
