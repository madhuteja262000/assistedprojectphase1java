package javaprogram;

public class Access1 {
	int hours =3;
	int mins = 47;
	
	public String name = "sonal";
	public String tool = "Selenium";
	
	
	private int a =3;
	private int b = 47;
	
	protected int x = 100;
	protected int z = 200;
	
	
}
