package javaprogram;

public class DoWhile {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 1;
		
		do {
			System.out.println("Today is wednesday");
			i++;
		}
		while(i<=7);
		
		System.out.println("Printed the meassage. i amaout of the loop");
		

	}



}
