$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"7120a333-7da7-48a6-a470-b71ceab2e965","feature":"Test the starHealth page on Chrome Browser","scenario":"Validate the Star Health Buy Now flow","start":1698156730610,"group":1,"content":"","tags":"","end":1698156786432,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});