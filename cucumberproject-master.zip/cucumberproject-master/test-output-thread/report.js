$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"5a9f55eb-f684-4524-a96e-c69145df869a","feature":"Testing rediff myPage","scenario":"User has to test if login on rediff is successful or not","start":1698031420686,"group":1,"content":"","tags":"","end":1698031434867,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});